# CO1_AT1 – Design and Analysis of Algorithms

Iterative programs in Python 3 (loops, series sums, prime numbers).

## Structure
```
CO1_AT1/
├── Question_1/
│   ├── Source_Code/      # 10 Python programs
│   └── Report/           # PDF report + screenshots of code and output
└── README.md
```

## Question 1 – programs
| # | Program | Time | Space |
|---|---------|------|-------|
| 1 | Factorial using a for loop | O(n) | O(1) |
| 2 | Fibonacci series up to n terms | O(n) | O(1) |
| 3 | Sum of first n natural numbers | O(n) | O(1) |
| 4 | Sum of squares of first n natural numbers | O(n) | O(1) |
| 5 | Sum of cubes of first n natural numbers | O(n) | O(1) |
| 6 | Generate 1 + 2 + ... + n and its sum | O(n) | O(1) |
| 7 | 1² + 2² + ... + n² | O(n) | O(1) |
| 8 | 1³ + 2³ + ... + n³ | O(n) | O(1) |
| 9 | Check whether a number is prime | O(√n) | O(1) |
| 10 | All primes between 1 and n | O(n√n) | O(1) |

## Run
```
cd Question_1/Source_Code
python 01_factorial.py
```
Full report: `Question_1/Report/Question_1_Report.pdf`
